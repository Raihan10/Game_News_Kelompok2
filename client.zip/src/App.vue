<template>
  <v-app>
    <router-view></router-view>
  </v-app>
</template>

<script>
</script>

<style>
#nprogress .bar {
  background: #E52B38 !important;
}
</style>
