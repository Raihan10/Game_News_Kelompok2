//const db = require('../config/db.config.js');
const db = require("../models");
const Game = db.game;
const Op = db.Sequelize.Op;
const fs = require("fs");
const { none } = require("../middleware/upload");
const stream = require('stream');

//Create and Save a new Game

exports.create = (req, res) => {
    // Validate request
    if (!req.body.judul_game) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
      return;
    }
  
    // Create a Tutorial
    const game = {
      id_game: req.body.id_berita,
      judul_game: req.body.judul_game,
      genre: req.body.genre,
      publisher: req.body.publisher,
      platform: req.body.platform,
      price : req.body.price,
      thumbnail_game:req.file,
      description : req.body.description,
      system_requirment : req.body.system_requirment,
      create_date: req.body.create_date,
      lastupdate_date: req.body.lastupdate_date,
    };
  
    // Save Tutorial in the database
    Game.create(game)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Game."
        });
      });
  };

    // Retrieve all News from the database.
    exports.findAll = (req, res) => {
        const judul_game= req.query.judul_berita;
        var condition = judul_game ? { judul_berita: { [Op.iLike]: `%${judul_game}%` } } : null;
      
        Game.findAll({ where: condition })
          .then(data => {
            res.send(data);
          })
          .catch(err => {
            res.status(500).send({
              message:
                err.message || "Some error occurred while retrieving news list."
            });
          });
    };

   // Find a single Tutorial with an id
   exports.findOne = (req, res) => {
    const id_game = req.params.id_game;

    Game.findByPk(id_game)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message: "Error retrieving Game with id=" + id_game
        });
      });
};

  
 // Update a News by the id in the request
 exports.update = (req, res) => {
    const id_game = req.params.id_game;

    Game.update(req.body, {
      where: { id_game: id_game }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Game was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Game with id=${id_game}. Maybe Game was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating Game with id=" + id_game
        });
      });
};

  // Delete a News with the specified id in the request
  exports.delete = (req, res) => {
    const id_game = req.params.id_game;

    Game.destroy({
      where: { id_game: id_game }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Game was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete Game with id=${id_game}. Maybe Game was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete Game with id=" + id_game
        });
      });
};

exports.updateThumbnail = async (req, res) => {
    // Get data per ID
    const id_game = req.params.id_game;
    //const newsPerID = 1;
    filename = req.file.filename;
    originalName = req.file.originalname;
  
      const gamePerID = {
        thumbnail: null
      };
      gamePerID.thumbnail = fs.readFileSync(
        __basedir + "/resources/uploads/" + filename
      );
      Game.update(gamePerID, {
        where: { id_game: id_game }
      })
        .then(num => {
          if (num == 1) {
            fs.writeFileSync(
              __basedir + "/resources/tmp/" + originalName,
              gamePerID.thumbnail
            );
            res.send({
              message: "News was updated successfully."
            });
          } else {
            res.send({
              message: `Cannot update News with id=${id_game}. Maybe Game was not found or req.body is empty!`
            });
          }
        })
        .catch(err => {
          res.status(500).send({
            message: "Error updating Game with id=" + id_game
          });
        });
  };


  exports.downloadFile = (req, res) => {
    Game.findByPk(req.params.id_game).then(data => {
      var fileContents = Buffer.from(data.thumbnail, "base64");
      var readStream = new stream.PassThrough();
      readStream.end(fileContents);
      
      res.set('Content-disposition', 'attachment; filename=Game_News');
      res.set('Content-Type', 'image/jpeg');
  
      readStream.pipe(res);
    }).catch(err => {
      console.log(err);
      res.json({msg: 'Error', detail: err});
    });
  }

  exports.getAllGame = async(req, res, next) => {
    try {
        const game = await Game.findAll({
            order : [
                ['id_game' , 'ASC']
            ]
        })
        if(game.length > 0) {
            res.status(200).json({
                message : 'Success retrieve all data',
                data : game
            })
        } else {
            res.status(404).send({
                message: 'Game not Found'
            })
        }
    }catch (err) {
        next(err)
    }
}

exports.showFile = (req, res) => {
  const id_game = req.params.id_game;
  
  News.findByPk(id_game)
  .then(data => {
    res.setHeader('Content-Type', 'image/jpeg');
    res.send(data.thumbnail);
  })
  .catch(err => {
     res.status(500).send({
     message: "Error retrieving News with id=" + id_game
      });
    });
  }