const uploadImage = require("../middleware/upload");


module.exports = app => {
  const game = require("../controller/game.controller.js");

  var router = require("express").Router();

	    // Create a new News
        router.post("/", game.create);
  
        // Retrieve all News
        router.get("/", game.findAll);
    
        //app.get("/all", news.getAll);
        
        // Retrieve a single News with id
        router.get("/:id_game", game.findOne);
      
        // Update a News with id
        router.put("/:id_game", game.update);
      
        // Delete a News with id
        router.delete("/:id_game", game.delete);
      
        // Create a new News
        router.delete("/", game.deleteAll);
    
        //Mendapatkan Image 
        //router.get("/api/news-thumbnail/:id_berita", news.downloadFile);
    
        //uplode/update image
        router.put("/game-thumbnail/:id_game", uploadImage.single("thumbnail"), game.updateThumbnail);
    
        router.get("/show-thumbnail/:id_game", game.showFile);

        app.use('/api/game', router);
	
}