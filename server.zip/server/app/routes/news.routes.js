module.exports = app => {
    const news = require("../controllers/news.controller.js");
    const game = require("../controllers/game.controller.js");
    const uploadImage = require("../middleware/upload");
  
    var router = require("express").Router();
  
    // Create a new Tutorial
    router.post("/news", news.create);
  
    // Retrieve all Tutorials
    router.get("/", news.findAll);
  
    // Retrieve all published Tutorials
    //router.get("/published", tutorials.findAllPublished);
  
    // Retrieve a single Tutorial with id
    router.get("/news/:id_berita", news.findOne);
  
    // Update a Tutorial with id
    router.put("/news/:id_berita", news.update);
  
    // Delete a Tutorial with id
    router.delete("/news/:id_berita", news.delete);
  
    // Create a new Tutorial
    router.delete("/news", news.deleteAll);

    router.get("/news-thumbnail/:id_berita", news.downloadFile);
    router.get("/show-thumbnail/:id_berita", news.showFile);
    router.put("/news-thumbnail/:id_berita", uploadImage.single("thumbnail"), news.updateThumbnail);

  
    // Create a new News
    router.post("/game", game.create);
  
    // Retrieve all News
    router.get("/game", game.findAll);

    //app.get("/all", news.getAll);
    
    // Retrieve a single News with id
    router.get("/game/:id_game", game.findOne);
  
    // Update a News with id
    router.put("/game/:id_game", game.update);
  
    // Delete a News with id
    router.delete("/game/:id_game", game.delete);
  
    // Create a new News
    router.delete("/game", game.deleteAll);

    //Mendapatkan Image 
    //router.get("/api/news-thumbnail/:id_berita", news.downloadFile);

    //uplode/update image
    router.put("/game-thumbnail/:id_game", uploadImage.single("thumbnail"), game.updateThumbnail);

    router.get("/show-thumbnail/:id_game", game.showFile);
    app.use('/api', router);
  };