module.exports = (sequelize, Sequelize) => {
    const Game = sequelize.define("game", {
      id_game: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement : true
      },
      judul_game: {
        type: Sequelize.STRING
      },
      genre: {
        type: Sequelize.STRING(30)
      },
      publisher: {
        type: Sequelize.STRING(30)
      },
      platform: {
        type: Sequelize.STRING(30)
      },
      price: {
        type: Sequelize.DECIMAL
      },
      thumbnail_game: {
        type: Sequelize.BLOB
      },
      description: {
        type: Sequelize.TEXT
      },
      system_requirment: {
        type: Sequelize.TEXT
      },
      createdAt: {
        field: 'create_date',
        type: Sequelize.DATE,
      },
      updatedAt: {
        field: 'lastupdate_date',
        type: Sequelize.DATE,
      },
    });
  
    return Game;
  };